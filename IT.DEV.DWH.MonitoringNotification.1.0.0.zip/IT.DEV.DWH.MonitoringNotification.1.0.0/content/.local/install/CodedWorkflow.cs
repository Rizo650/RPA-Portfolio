using UiPath.CodedWorkflows;

namespace IT.DEV.DWH.MonitoringNotification
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}