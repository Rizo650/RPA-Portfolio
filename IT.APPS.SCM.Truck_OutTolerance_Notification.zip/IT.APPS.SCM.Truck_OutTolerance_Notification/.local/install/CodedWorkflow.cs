using UiPath.CodedWorkflows;

namespace IT.APPS.SCM.Truck_OutTolerance_Notification
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}