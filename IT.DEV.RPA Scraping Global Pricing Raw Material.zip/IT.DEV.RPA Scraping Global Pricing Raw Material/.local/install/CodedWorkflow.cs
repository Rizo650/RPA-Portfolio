using UiPath.CodedWorkflows;
using UiPath.Mail.Activities.Api;
using UiPath.CodedWorkflows.DescriptorIntegration;

namespace RPAScrapingGlobalPricingRawMaterial
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{typeof(UiPath.Mail.Activities.Api.IMailService)};
        }

        protected UiPath.Mail.Activities.Api.IMailService mail { get => serviceContainer.Resolve<UiPath.Mail.Activities.Api.IMailService>(); }
    }
}

namespace RPAScrapingGlobalPricingRawMaterial.ObjectRepository
{
    public static class Descriptors
    {
    }
}

namespace RPAScrapingGlobalPricingRawMaterial._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }

        public IElementDescriptor ParentElement { get; set; }

        public IElementDescriptor Element { get; set; }
    }
}